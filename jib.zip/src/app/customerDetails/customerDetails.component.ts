import { Component, Input, OnInit, Output, EventEmitter } from "@angular/core";
import { Customer, CustomerDetail } from "../app.component";

@Component({
  selector: "customer-details",
  templateUrl: "./customerDetails.component.html",
  styleUrls: ["./customerDetails.component.scss"],
})
export class CustomerDetails implements OnInit {
  @Input() customerDetailsRecords;
  @Input() selectedId;
  constructor() {}

  ngOnInit() {
    console.log(this.customerDetailsRecords);
  }
}
